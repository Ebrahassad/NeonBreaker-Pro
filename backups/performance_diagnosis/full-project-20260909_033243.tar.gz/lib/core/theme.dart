import 'package:flutter/material.dart';

class NeonColors {
  static const background = Color(0xFF03020A);
  static const background2 = Color(0xFF090414);
  static const surface = Color(0xFF10091C);

  static const cyan = Color(0xFF39F4FF);
  static const pink = Color(0xFFFF32D2);
  static const purple = Color(0xFF8B4DFF);
  static const green = Color(0xFF49FF9A);
  static const orange = Color(0xFFFF9138);
  static const blue = Color(0xFF4A8DFF);
  static const yellow = Color(0xFFFFD34E);
}

/// Selectable background color themes (Settings > Background).
/// Each entry is a 3-stop gradient used for both the home screen and the
/// in-game background.
class BackgroundThemes {
  static const List<String> names = [
    'Light Neon',
    'Balanced Neon',
    'Deep Neon',
  ];

  static const List<List<Color>> gradients = [
    // Light Neon
    [
      Color(0xFF173A52),
      Color(0xFF10243A),
      Color(0xFF091525),
    ],

    // Balanced Neon
    [
      Color(0xFF101F38),
      Color(0xFF0A1328),
      Color(0xFF050B18),
    ],

    // Deep Neon
    [
      Color(0xFF0B1024),
      Color(0xFF050817),
      Color(0xFF02030B),
    ],
  ];

  static const List<Color> swatch = [
    NeonColors.cyan,
    NeonColors.purple,
    Color(0xFF65708A),
  ];

  static List<Color> colorsFor(int index) {
    if (index < 0 || index >= gradients.length) {
      return gradients[0];
    }
    return gradients[index];
  }
}

ThemeData neonTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: NeonColors.background,
    colorScheme: ColorScheme.fromSeed(
      seedColor: NeonColors.cyan,
      brightness: Brightness.dark,
    ),
  );
}
