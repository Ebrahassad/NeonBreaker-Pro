import 'package:audioplayers/audioplayers.dart';

import 'save_service.dart';

class SoundService {
  SoundService._();

  static final SoundService instance = SoundService._();

  static const String _paddleAsset = 'audio/paddle_hit.wav';
  static const String _brickAsset = 'audio/brick_break.wav';
  static const String _wallAsset = 'audio/wall_hit.wav';

  static const int _poolSize = 4;

  SaveService? _save;
  bool _ready = false;

  final List<AudioPlayer> _paddlePool = [];
  final List<AudioPlayer> _brickPool = [];
  final List<AudioPlayer> _wallPool = [];

  int _paddleIndex = 0;
  int _brickIndex = 0;
  int _wallIndex = 0;

  bool get _enabled => _save?.soundEnabled ?? true;

  Future<void> init(SaveService save) async {
    _save = save;

    if (_ready) return;

    try {
      for (var i = 0; i < _poolSize; i++) {
        _paddlePool.add(AudioPlayer(playerId: 'nb_paddle_$i'));
        _brickPool.add(AudioPlayer(playerId: 'nb_brick_$i'));
        _wallPool.add(AudioPlayer(playerId: 'nb_wall_$i'));
      }

      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  void playPaddle() {
    _play(
      _paddlePool,
      () => _paddleIndex = (_paddleIndex + 1) % _paddlePool.length,
      () => _paddleIndex,
      _paddleAsset,
      .65,
    );
  }

  void playBrick() {
    _play(
      _brickPool,
      () => _brickIndex = (_brickIndex + 1) % _brickPool.length,
      () => _brickIndex,
      _brickAsset,
      .78,
    );
  }

  void playWall() {
    _play(
      _wallPool,
      () => _wallIndex = (_wallIndex + 1) % _wallPool.length,
      () => _wallIndex,
      _wallAsset,
      .42,
    );
  }

  void _play(
    List<AudioPlayer> pool,
    void Function() advance,
    int Function() index,
    String asset,
    double volume,
  ) {
    if (!_ready || !_enabled || pool.isEmpty) return;

    try {
      final player = pool[index()];
      advance();

      player
          .play(
            AssetSource(asset),
            mode: PlayerMode.lowLatency,
            volume: volume,
          )
          .catchError((_) {});
    } catch (_) {}
  }
}
